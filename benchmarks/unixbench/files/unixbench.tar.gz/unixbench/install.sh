#!/usr/bin/env bash
build_unixbench() {
    set -e
    myOBJPATH=/tmp/unixbench
    if [ ! -d $myOBJPATH ]
    then
        mkdir -p $myOBJPATH
    fi
    make
}

build_unixbench
