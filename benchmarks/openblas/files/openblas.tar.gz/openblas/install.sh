build_OpenBLAS() {
    set -e
    ARCH=`uname -i`
    SrcPath=$(cd `dirname $0`; pwd)
    if [ $ARCH = "aarch64" ]; then
        make HOSTCC=gcc TARGET=ARMV8
        cd benchmark
        make HOSTCC=gcc TARGET=ARMV8
    else
        make
        cd benchmark
        make
    fi
}

build_OpenBLAS

