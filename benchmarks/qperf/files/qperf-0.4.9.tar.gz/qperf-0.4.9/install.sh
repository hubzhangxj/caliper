build_scimark() {
    set -e
    ARCH=`uname -i`
    if [ $ARCH = "aarch32" ]; then
        ARMCROSS=arm-linux-gnueabihf
        GCC=${ARMCROSS}-gcc
        STRIP=${ARMCROSS}-strip
    elif [ $ARCH = "aarch64" ]; then
        ARMCROSS=aarch64-linux-gnu
        GCC=${ARMCROSS}-gcc
        STRIP=${ARMCROSS}-strip
    fi
    SrcPath=/tmp/qperf-0.4.9
    BuildPATH="/tmp/build.qperf"
    myOBJPATH=/usr/bin
    mkdir -p $BuildPATH
    if [ $ARCH = "aarch64" -o $ARCH = "aarch32" ]
    then
        cd $BuildPATH
        export ac_cv_func_malloc_0_nonnull=yes
        $SrcPath/configure --disable-shared --enable-static --prefix=$BuildPATH --host=$ARMCROSS  CC=$GCC CXX=$(GCC//gcc/g++)
        make
        cp src/qperf $myOBJPATH
    else
        cd $BuildPATH
        $SrcPath/configure --prefix=$BuildPATH
        make
        cp src/qperf $myOBJPATH
    fi
}

build_scimark
